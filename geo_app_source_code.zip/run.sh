#!/bin/bash
# ==============================================================================
# Script Peluncur GEO Audit App Nusantara
# ==============================================================================

echo "🧭 Memulai GEO Audit App Nusantara..."

# Cek uv di ~/.local/bin
if [ -f "$HOME/.local/bin/uv" ]; then
    UV_BIN="$HOME/.local/bin/uv"
elif command -v uv &> /dev/null; then
    UV_BIN="uv"
else
    echo "Menggunakan Python sistem..."
fi

if [ -n "$UV_BIN" ]; then
    echo "⚡ Menjalankan Streamlit via uv..."
    "$UV_BIN" run --python 3.11 --with streamlit --with plotly --with pandas streamlit run app.py
else
    if command -v python3 &> /dev/null; then
        pip install -r requirements.txt
        streamlit run app.py
    else
        echo "❌ Python tidak ditemukan. Silakan buka file standalone_preview.html langsung di browser Anda!"
        open standalone_preview.html
    fi
fi
