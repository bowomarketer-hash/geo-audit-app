# 🧭 GEO Audit App Nusantara

> **Aplikasi Web Interaktif Audit Kesiapan Generative Engine Optimization (GEO) untuk UMKM dan Konsultan Digital Indonesia.**

Aplikasi ini dirancang untuk mengukur dan meningkatkan kesiapan website serta merek lokal Indonesia agar direkomendasikan dan disitasi sebagai sumber jawaban terpercaya oleh mesin pencari AI generasi baru berbasis **Retrieval-Augmented Generation (RAG)** seperti **ChatGPT Search, Perplexity AI, Claude, Google Gemini, dan Google AI Overviews**.

---

## 🌟 Fitur Utama

### 1. Profil Data UMKM & Tombol Utama "🌐 Jalankan Live Audit Web"
- Input Nama Merek, URL Landing Page, Kategori Bisnis (Niche), Kontak WhatsApp, dan Lokasi Operasional.
- Detail produk unggulan, kisaran harga, dan keunggulan kompetitif.
- **Tombol Utama "🌐 Jalankan Live Audit Web"**: Menggabungkan inspeksi server live (HTTP/HTTPS, TTFB, robots.txt AI Bot) dan analisis heuristik profil inputan untuk:
  1. Mengisi checklist 10 indikator audit GEO secara instan & otomatis.
  2. Menghitung skor total kesiapan dan status kematangan AI (Dasar, Berkembang, Kompetitif, Siap GEO AI).
  3. Memetakan kesenjangan kutipan (*Citation Gap*) dan rencana aksi perbaikan prioritas.
  4. Menghasilkan kode Schema JSON-LD, teks BLUF, `robots.txt`, dan FAQ percakapan di modul Auto-Fix Generator.
  5. Menyesuaikan panduan edukasi strategi GEO spesifik untuk kategori bisnis Anda.
- Tersedia tombol bantuan **"📋 Preset Demo"** (studi kasus Kopi Toraja) dan **"🔄 Kosongkan Cek"** yang tersusun rapi di bawah tombol utama.

### 2. Fitur Unggulan: "🌐 Live Crawler Otomatis & Server Health Check"
- Tombol **"🌐 Jalankan Live Audit Web"** (tersedia di Sidebar dan Tab Checklist).
- **Fetch Otomatis ke URL Target**: Mengirimkan HTTP request live untuk memeriksa respons server langsung.
- **Pemeriksaan `robots.txt` Cerdas**:
  - Mengunduh dan mengurai file `/robots.txt` menggunakan `urllib.robotparser` dan analisis blok direktif.
  - Mendeteksi izin spesifik untuk 4 crawler AI utama: **GPTBot** (OpenAI), **ClaudeBot** (Anthropic), **Google-Extended** (Google Gemini/AI Overviews), dan **PerplexityBot** (Perplexity AI).
  - Jika seluruh bot AI diizinkan, **Indikator 1 otomatis tercentang**!
- **Pengukuran HTTPS & TTFB (Time-To-First-Byte)**:
  - Memvalidasi sertifikat enkripsi SSL (HTTPS).
  - Mengukur waktu respons server awal secara presisi.
  - Jika koneksi HTTPS aktif dan waktu muat **< 3.0 detik**, **Indikator 2 otomatis tercentang**!
- **Perhitungan Skor Instan**: Skor total (0–100), visualisasi Radar Chart & Bar Chart, kesenjangan kutipan (*Citation Gap*), dan Auto-Fix Generator langsung terhitung tanpa perlu centang manual.

### 3. Checklist Audit 10 Indikator Kunci (4 Pilar GEO)
Perhitungan skor berbobot proporsional (0–100):
- **Pilar 1: Aksesibilitas Teknis & AI Crawlers (Bobot 20%)**
  - Izin AI Crawler (GPTBot, ClaudeBot, Google-Extended, PerplexityBot) di `robots.txt` *(10%)*
  - Enkripsi HTTPS & Kecepatan Muat Situs < 3 Detik *(10%)*
- **Pilar 2: Kejelasan Struktur Konten & BLUF (Bobot 30%)**
  - Ringkasan produk, keunggulan, dan harga di paragraf teratas (Format BLUF) *(7.5%)*
  - Hierarki heading semantik yang teratur (H1, H2, H3) untuk chunking AI *(7.5%)*
  - Bagian FAQ Percakapan (Conversational Q&A) *(7.5%)*
  - Data kuantitatif spesifik, harga pasti, gramasi, dan sertifikasi Halal/BPOM *(7.5%)*
- **Pilar 3: Data Terstruktur / Schema JSON-LD (Bobot 20%)**
  - LocalBusiness / Organization Schema (Nama, NAP, Kontak WA) *(10%)*
  - Product Schema atau FAQPage Schema *(10%)*
- **Pilar 4: Otoritas Merek & Sebutan Luar / Off-Page (Bobot 30%)**
  - Video ulasan/demonstrasi YouTube ber-transkrip & subtitle *(15%)*
  - Sebutan luar di Google Business Profile, media/blog lokal, forum *(15%)*

### 3. Kategori Kematangan (Maturity Tiers)
- 🟢 **80–100: AI-Ready (Sangat Siap)** — Berpeluang tinggi disitasi langsung dalam jawaban rangkuman AI.
- 🟡 **50–79: Needs Optimization (Cukup Siap)** — Dikenali namun belum menjadi prioritas rekomendasi utama.
- 🔴 **0–49: Invisible to AI (Belum Siap)** — Berisiko diabaikan atau digantikan oleh kompetitor saat konsumen bertanya ke AI.

### 4. Dasbor Interaktif & Visualisasi
- **Radar Chart 4 Pilar**: Memperlihatkan keseimbangan kesiapan pilar secara visual.
- **Bar Chart Skor vs Bobot**: Membandingkan poin riil yang diperoleh dengan bobot maksimal.
- **Analisis Kesenjangan Kutipan (Citation Gap Analysis)**: Menjelaskan alasan spesifik mengapa AI ragu menyitasi web Anda.
- **Rekomendasi Prioritas**: Terbagi menjadi *Quick Wins* (< 1 hari) dan *Strategic Improvements* (1-4 minggu).
- **Ekspor Laporan Audit**: Unduh laporan audit lengkap format Markdown (`.md`).

### 5. 🤖 Automated AI Testing & Audit Engine (Fitur Baru)
Modul pengujian otomatis terhadap 5 mesin pencari AI generasi baru (**ChatGPT, Perplexity, Claude, Gemini, dan Google AI Overviews**):
- **Brand Mention Detector**:
  - Deteksi visual instan (🟢 Mentioned / 🔴 Not Mentioned).
  - Frekuensi sebutan dan posisi teks (Awal Paragraf, Tengah, Catatan Kaki).
  - Analisis sentimen leksikal (Positif 🟢, Netral 🟡, Negatif 🔴).
- **Citation Link Extractor**:
  - Mengekstrak seluruh URL, hyperlink markdown, dan footnote sitasi.
  - Mengelompokkan sumber ke dalam 5+ kategori: 🌐 Website Resmi, 📹 Video YouTube, 📰 Media Berita/Listicles, 💬 Forum Komunitas, 📍 Profil Bisnis Lokal (Google Business Profile).
  - Mengidentifikasi tautan aset resmi milik UMKM pengguna.
- **Citation Gap Map & Share of Voice**:
  - Matriks Kesenjangan (*Gap Table*): Kueri | Status Merek Anda | Pesaing Muncul | Domain Sumber.
  - Visualisasi Plotly: Bar Chart *Share of Voice (%)* Merek vs Pesaing + Heatmap Matriks Kueri per Mesin AI.
  - *Auto-Actionable Insights*: Rekomendasi taktis otomatis untuk menutup celah sitasi kompetitor.
- **Pilihan Moda Pengujian**:
  - **Simulation / Manual Mode (Default)**: 25 pengujian benchmark otomatis atau tempel (*paste*) teks jawaban AI.
  - **API Mode (Real-Time)**: Masukkan API Key (OpenAI / Perplexity) untuk pencarian langsung real-time.
- **Fitur Ekspor Lengkap**: Unduh laporan pengujian AI format CSV, JSON, dan Markdown.

### 6. ⚡ Auto-Fix Generator Instan
- **Generator Schema.org JSON-LD**: Siap pakai untuk `LocalBusiness`, `Organization`, `FAQPage`, dan `Product`.
- **Generator Draf Paragraf BLUF**: Template ringkasan 50 kata pertama berstandar semantic chunking AI.
- **Generator robots.txt Ramah AI**: Mengizinkan GPTBot, ClaudeBot, Google-Extended, dan PerplexityBot.
- **Generator 5 FAQ Percakapan**: Tanya jawab gaya bahasa alami yang memadankan prompt pertanyaan konsumen.

---

## 🚀 Cara Menjalankan Aplikasi

### Opsi A: Menggunakan Streamlit (Python)

1. Pastikan Python 3.9+ sudah terpasang di komputer Anda.
2. Pasang dependensi yang dibutuhkan:
   ```bash
   pip install -r requirements.txt
   ```
   *(Atau dengan `uv`: `uv pip install -r requirements.txt`)*
3. Jalankan aplikasi Streamlit:
   ```bash
   streamlit run app.py
   ```
4. Buka tautan lokal di browser Anda: `http://localhost:8501`.

---

### Opsi B: Standalone Interactive Preview (Tanpa Install Server)

Cukup klik dua kali atau buka berkas `standalone_preview.html` di browser favorit Anda (Google Chrome, Safari, Edge, Mozilla Firefox). Seluruh checklist, kalkulator skor, grafik radar, grafik batang, dan Auto-Fix generator dapat langsung digunakan secara penuh dan interaktif!

---

## 📂 Struktur Berkas Proyek

```
GEO App Nusantara/
├── app.py                      # Aplikasi utama berbasis Streamlit (5 Tab Navigasi)
├── ai_testing_engine.py        # Mesin Brand Mention Detector, Citation Extractor, Gap Map & API
├── geo_engine.py               # Logika audit, pembobotan skor, citation gaps, dan rekomendasi
├── autofix_generators.py       # Generator Schema JSON-LD, BLUF, robots.txt, dan FAQ
├── requirements.txt            # Dependensi Python (streamlit, plotly, pandas)
├── standalone_preview.html     # Versi mandiri HTML/JS interaktif siap buka di browser
└── README.md                   # Dokumentasi panduan penggunaan & arsitektur
```

---

## 💡 Mengapa UMKM Indonesia Wajib Memahami GEO?

Pada era pencarian tradisional, memenangkan peringkat 1 Google diukur dari kepadatan kata kunci (*keyword stuffing*) dan jumlah backlink. Di era generative search (ChatGPT, Perplexity, Gemini, Google AI Overviews), mesin AI tidak lagi menampilkan 10 daftar tautan biru, melainkan **merangkum satu jawaban terpadu**. 

Jika website UMKM tidak memiliki:
1. Akses terbuka untuk crawler AI di `robots.txt`,
2. Paragraf pembuka berbasis fakta (BLUF),
3. Identitas mesin yang pasti via Schema JSON-LD, dan
4. Validasi review di luar website,

maka mesin AI akan menganggap bisnis tersebut tidak terverifikasi dan melewatinya. **GEO Audit App Nusantara** hadir untuk memastikan UMKM lokal Indonesia tidak tertinggal dan siap memenangkan era pencarian berbasis AI.
